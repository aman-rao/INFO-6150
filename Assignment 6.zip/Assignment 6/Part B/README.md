# Stopwatch Application

## Overview
This is a simple Stopwatch application built using HTML, CSS, and JavaScript. It features a time display, a date picker, and three control buttons (Start, Stop, and Reset). The stopwatch logic utilizes modern JavaScript features like Async/Await, Promises, and setInterval/clearInterval.

## Features
- Displays time in HH:MM:SS format.
- A date picker to select a date (once selected, it cannot be changed until reset is clicked).
- Start, Stop, and Reset buttons to control the stopwatch.
- Implements Async/Await, Promises, and setInterval/clearInterval for stopwatch functionality.
- Basic CSS styling for a clean and organized UI.

## Technologies Used
- HTML
- CSS
- JavaScript (ES6+)

## Files Included
- `stopwatch.html` - The main HTML file containing the structure.
- `styles.css` - The CSS file for styling the application.
- `stopwatch.js` - The JavaScript file implementing the stopwatch logic.

## Installation & Usage
1. Clone this repository or download the files.
2. Open `stopwatch.html` in a web browser.
3. Select a date (optional), then click 'Start' to begin timing.
4. Use 'Stop' to pause and 'Reset' to clear the timer and re-enable the date picker.


