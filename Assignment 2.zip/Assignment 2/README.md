# Professional Portfolio Website

## Project Description
This project is a professional portfolio website designed to showcase skills, projects, and achievements using HTML5, CSS, and JavaScript. The website has various sections, including a professional gallery, testimonials, a contact form, and an overview of completed projects. It incorporates modern web design principles and responsive layouts to enhance user experience.

## Project Structure
- **HTML Elements**: The website uses a variety of HTML5 elements like `header`, `footer`, `section`, `article`, `form`, `table`, and media-related tags.
- **CSS**: All styling is handled through an external CSS file (`styles.css`), focusing on a cohesive color scheme (#FFC107, #283593, #EEEEEE) and responsive design.
- **Media**: Images are included to highlight projects and testimonials.

## Website Features
1. **Header and Navigation**:
   - A responsive navigation bar with links to sections such as Home, Projects, Testimonials, and Contact.
   - Sticky header for improved accessibility.

2. **Projects Gallery**:
   - A gallery displaying past projects with hover effects that reveal descriptions.

3. **Testimonials Section**:
   - A section showcasing client testimonials, complete with images styled as circles and a hover effect for the container.

4. **Contact Form**:
   - A form for users to contact the developer, featuring `mailto` functionality to open the default email client.

5. **Footer**:
   - A footer containing social media links, contact information, and additional resources.

6. **Responsive Design**:
   - Fully responsive layout that adjusts for tablets, smartphones, and desktops using media queries.

## HTML5 Tags Used
- `<header>`: For the website header and navigation.
- `<footer>`: For the footer section.
- `<nav>`: For navigation links.
- `<section>`: To divide content into logical sections.
- `<article>`: For self-contained pieces of content like testimonials.
- `<form>`: For the contact submission form.
- `<img>`: To display images in the gallery and testimonials.
- `<button>`: For interactivity in the form.
- `<table>`: For structured content like the testimonials or data summaries.
- `<a>`: For navigation and linking, including `mailto` and `tel` attributes.

## Git and Submission
- The project has been pushed to a GitHub repository.
- Submission includes both a ZIP file containing all project files and a link to the GitHub repository.

## How to Run
1. Clone the repository from GitHub.
2. Ensure all files are in the correct directory structure.
3. Open `index.html` in your browser to view the website.
4. Test responsiveness by resizing the browser window or viewing on different devices.

