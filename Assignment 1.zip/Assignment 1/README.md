# Movie Reviews Website

## Assignment Description 
This project is a Movie Review website built using HTML5 and CSS. The site has various sections, including a section showcasing top movies, audio and video clips from the movies, a review table and a section to write your own review. Serveral crucial HTML5 elements have been used to improve user experience.

## Project Structure
- **HTML Elements** - Favicon, Header, Section, Article, Aside, Footer, Table, Form (Input, Datalist), Images(fig,ficaption), Hyperlink, Button, Audio, Video, Details and Summary, tel and mailto properties

- **CSS**: All styling is done using an external CSS file (`styles.css`) for the layout and color schemes.

- **Media**: Videos and audio taken from open source platforms.

## Website Features
1. **Favicon**: A custom favicon included in the header using `<link rel="icon" href="images/favicon.ico.png" type="image/x-icon">`

2. **Header and Navigation**

The navigation bar features links to several sections such as the Home, Movies, Contact Us, Write a Review and View Reviews sections.

3. **Home Section**: A welcome message.

4. **Top Movies**: A section consisting of three movies with various audio and video clips from the respective movies.

5. **Reviews Table**: A reviews table consisting of some movies and their respective reviews.

6. **Reviews Form**: A reviews form that consists of a couple of input fields with users name email and the review along with a datalist allowing the user to pick the movie they wish to review.

7. **Aside**: An aside section consisting of links to the latest movie trailers, movie blogs, some facts and upcoming events.

8. **Footer**: A contact information portion with mailto and telephone properties.


## HTML5 tags used

- `<header>`: For the website header and navigation.
- `<footer>`: For the website's footer.
- `<nav>`: For the navigation bar.
- `<section>`: To divide content into logical sections.
- `<article>`: 
- `aside`: To create a seprate content bar on the side.
- `<form>`: For creating the review submission form.
- `<audio>`: For embedding ambient audio from a photoshoot.
- `<video>`: For the video gallery.
- `<table>`: For structured contact information.
- `<a href="tel:">` and `<a href="mailto:">`: For clickable phone and email contact details.
- `<summary>`: To provide a collapsible text for the sections below the figures.
- `button`: For the form.
- `details`: For details regarding the movie.

## Git and Submission
- The project has been pushed to a private GitHub repository and will be submitted as a ZIP file on Canvas along with the GitHub URL.


## How to Run
1. Clone the repository from GitHub.
2. Open `index.html` in your browser.
3. Ensure `styles.css` and media files are in the correct directories for the best experience.

